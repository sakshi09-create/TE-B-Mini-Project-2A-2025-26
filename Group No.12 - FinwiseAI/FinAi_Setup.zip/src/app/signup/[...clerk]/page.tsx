import { SignUp } from '@clerk/nextjs'

export default function ClerkSignUp() {
  return <SignUp />
}

